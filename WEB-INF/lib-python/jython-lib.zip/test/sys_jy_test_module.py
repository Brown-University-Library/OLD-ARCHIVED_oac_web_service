class Foobar(object):
    pass
